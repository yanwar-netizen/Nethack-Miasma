#include "miasma.h"

Room** Map() {
	Room** rooms;
	rooms = malloc(sizeof(Room*) * 5);
	// included only inner width and height

	rooms[0] = CreateRoom(10, 5, 5, 13);
	DrawRoom(rooms[0]);
	rooms[1] = CreateRoom(5, 20, 3, 10);
	DrawRoom(rooms[1]);
	rooms[2] = CreateRoom(13, 33, 4, 13);
	DrawRoom(rooms[2]);
	rooms[3] = CreateRoom(6, 42, 3, 4);
	DrawRoom(rooms[3]);

	ConnectDoors(&rooms[0]->doors[1], &rooms[1]->doors[3]);
	ConnectDoors(&rooms[0]->doors[0], &rooms[1]->doors[2]);
	ConnectDoors(&rooms[1]->doors[1], &rooms[2]->doors[0]);
	ConnectDoors(&rooms[1]->doors[0], &rooms[3]->doors[0]);

	return rooms;
}

char** saveFloor() {
	char** position;
	position = malloc(sizeof(char*) * 100);
	for (int i = 0; i < 100; i++) {
		position[i] = malloc(sizeof(char)*100);
		for (int j = 0; j < 100; j++) {
			position[i][j] = mvinch(i, j);
		}
	}
	return position;
}